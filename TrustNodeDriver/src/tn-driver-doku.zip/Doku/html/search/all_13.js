var searchData=
[
  ['zerocopy_5frx',['zerocopy_rx',['../df/df2/_i_n_r-_p_c_i_8h.html#aa9351fc826978b50f453a338e27d04da',1,'INR-PCI.h']]],
  ['zerocopy_5ftx',['zerocopy_tx',['../df/df2/_i_n_r-_p_c_i_8h.html#a65604782635183d5c649f2fbd478eca5',1,'INR-PCI.h']]]
];
