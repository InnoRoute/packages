var searchData=
[
  ['ids',['ids',['../d0/d29/main_8c.html#a4a12a64d56df9af7c0af998356f07b01',1,'main.c']]],
  ['inr_5fnw',['INR_NW',['../d0/d29/main_8c.html#abcaae765e427c46f9257b243ed9d5e80',1,'main.c']]],
  ['inr_5fnw_5fheader_5fops',['INR_NW_header_ops',['../dd/de5/_i_n_r-_n_w_8h.html#a6a43442ffc8bbda8333c244e1cf7a1ac',1,'INR-NW.h']]],
  ['inr_5fnw_5fnetdev_5fops',['INR_NW_netdev_ops',['../dd/de5/_i_n_r-_n_w_8h.html#aec4f4a32143364de3f75818d325e3096',1,'INR-NW.h']]],
  ['inr_5fpci_5frx_5fdescriptor_5fbase',['INR_PCI_rx_descriptor_base',['../dc/dc8/_i_n_r-_p_c_i_8c.html#a0aab437e0450e23b48b0ed117e2e3364',1,'INR-PCI.c']]],
  ['inr_5fpci_5frx_5fdescriptor_5fcurrent',['INR_PCI_rx_descriptor_current',['../dc/dc8/_i_n_r-_p_c_i_8c.html#a94b5b542c42ca689a80e84a03e6f1cae',1,'INR-PCI.c']]],
  ['inr_5fpci_5frx_5fdescriptor_5fpool_5fdma_5froot',['INR_PCI_rx_descriptor_pool_dma_root',['../dc/dc8/_i_n_r-_p_c_i_8c.html#a16698462bae72a524f1370cbc3c962d6',1,'INR-PCI.c']]],
  ['inr_5fpci_5frx_5fdescriptor_5fpool_5froot',['INR_PCI_rx_descriptor_pool_root',['../dc/dc8/_i_n_r-_p_c_i_8c.html#a26b0eac35a5c2a056eb1f9f956b4094e',1,'INR-PCI.c']]],
  ['inr_5fpci_5frx_5fdescriptor_5fring',['INR_PCI_rx_descriptor_ring',['../dc/dc8/_i_n_r-_p_c_i_8c.html#a82b0e934f3d754ce0f8219069e5319ab',1,'INR-PCI.c']]],
  ['inr_5fpci_5ftx_5fdescriptor_5fbase',['INR_PCI_tx_descriptor_base',['../dc/dc8/_i_n_r-_p_c_i_8c.html#a5b6ca907b547286c37078d562585dece',1,'INR-PCI.c']]],
  ['inr_5fpci_5ftx_5fdescriptor_5fcurrent',['INR_PCI_tx_descriptor_current',['../dc/dc8/_i_n_r-_p_c_i_8c.html#ac3f12ba58c3ead694e896e66b88c2a68',1,'INR-PCI.c']]],
  ['inr_5fpci_5ftx_5fdescriptor_5fring',['INR_PCI_tx_descriptor_ring',['../dc/dc8/_i_n_r-_p_c_i_8c.html#a28f724f7c989224790f2c24cdd05a245',1,'INR-PCI.c']]],
  ['inr_5fpci_5ftx_5fdescriptor_5funmap_5fcurrent',['INR_PCI_tx_descriptor_unmap_current',['../dc/dc8/_i_n_r-_p_c_i_8c.html#a83be7cc1825e44225462f6ea294f86cf',1,'INR-PCI.c']]],
  ['inr_5frx_5fring',['INR_RX_Ring',['../dc/dc8/_i_n_r-_p_c_i_8c.html#a24e18802296d35c8cc658364a7896e5a',1,'INR-PCI.c']]],
  ['inr_5ftx_5fring',['INR_TX_Ring',['../dc/dc8/_i_n_r-_p_c_i_8c.html#a7566bc20d9046b9acbb279db2095e20d',1,'INR-PCI.c']]]
];
