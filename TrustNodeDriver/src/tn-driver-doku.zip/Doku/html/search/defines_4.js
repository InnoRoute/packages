var searchData=
[
  ['napi_5fenable',['NAPI_enable',['../d6/d03/_i_n_r-_n_a_p_i_8h.html#acbc9c68f292e6e8596a3de2d811b1d83',1,'INR-NAPI.h']]]
];
