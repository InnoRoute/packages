var searchData=
[
  ['testdate_5fsize',['testdate_size',['../df/df2/_i_n_r-_p_c_i_8h.html#a82cf57c71a0d179e367eaa185c969557',1,'INR-PCI.h']]]
];
