var searchData=
[
  ['offset',['offset',['../d2/db6/struct_i_n_r___p_c_i__rx__descriptor__ring__entry.html#ad3b84006086822db04cbf62757be7ffa',1,'INR_PCI_rx_descriptor_ring_entry']]]
];
