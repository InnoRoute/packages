var searchData=
[
  ['buffer',['buffer',['../dc/d3a/struct_i_n_r___p_c_i__tx__descriptor.html#a6f3315499b06e8559a4c064ee7d2a57b',1,'INR_PCI_tx_descriptor::buffer()'],['../d5/d3e/struct_i_n_r___p_c_i__rx__descriptor.html#a55af0fc445cc9d4e3896436ef8abe075',1,'INR_PCI_rx_descriptor::buffer()']]]
];
