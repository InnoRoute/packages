var searchData=
[
  ['refillcount',['refillcount',['../dc/dc8/_i_n_r-_p_c_i_8c.html#aba34a87a54aa67b4f4e161bc6f9c2b80',1,'INR-PCI.c']]],
  ['remove',['remove',['../d0/d29/main_8c.html#a28d5841b26c9924ab02d6adb235e9848',1,'main.c']]],
  ['rx_5fdescriptor_5fpool_5ffree',['rx_descriptor_pool_free',['../dc/dc8/_i_n_r-_p_c_i_8c.html#ad826d814b9ad0f97206bdfd613a7fa01',1,'INR-PCI.c']]],
  ['rx_5fdescriptor_5fpool_5flength',['rx_descriptor_pool_length',['../dc/dc8/_i_n_r-_p_c_i_8c.html#aae96187ffb4bd3c8a6a46f921f30c3cb',1,'INR-PCI.c']]]
];
