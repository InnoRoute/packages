var searchData=
[
  ['vlan',['VLAN',['../dc/d3a/struct_i_n_r___p_c_i__tx__descriptor.html#a74593a0d786bfb6992a46d634a37d731',1,'INR_PCI_tx_descriptor']]]
];
