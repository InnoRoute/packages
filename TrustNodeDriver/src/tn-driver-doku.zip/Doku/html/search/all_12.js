var searchData=
[
  ['xpcie_5firqhandler',['XPCIe_IRQHandler',['../dc/dc8/_i_n_r-_p_c_i_8c.html#a1c0927891fa571e8aec98ebe5fd266f6',1,'XPCIe_IRQHandler(int irq, void *dev_id, struct pt_regs *regs):&#160;INR-PCI.c'],['../df/df2/_i_n_r-_p_c_i_8h.html#a1c0927891fa571e8aec98ebe5fd266f6',1,'XPCIe_IRQHandler(int irq, void *dev_id, struct pt_regs *regs):&#160;INR-PCI.h']]]
];
