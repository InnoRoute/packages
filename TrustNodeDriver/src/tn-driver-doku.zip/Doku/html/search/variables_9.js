var searchData=
[
  ['page',['page',['../d2/db6/struct_i_n_r___p_c_i__rx__descriptor__ring__entry.html#ab17d4a4ae6f92408110b4800ffabe555',1,'INR_PCI_rx_descriptor_ring_entry']]],
  ['paged',['paged',['../d4/dad/struct_i_n_r___p_c_i__tx__descriptor__ring__entry.html#acf71b2952a6fb4054bd869b56ccf3248',1,'INR_PCI_tx_descriptor_ring_entry']]],
  ['procfs_5fbuffer_5fsize',['procfs_buffer_size',['../d2/d08/_i_n_r-ctl_8c.html#a6899cc17f88576d95e2f628c5f6cb151',1,'INR-ctl.c']]]
];
