var searchData=
[
  ['inr_5ftn_5fovsctl_5fcmd_5ftype',['INR_TN_ovsctl_cmd_type',['../dc/d62/_i_n_r-ctl_8h.html#ac05c44c7c865ae369322d0ff95776878',1,'INR-ctl.h']]]
];
