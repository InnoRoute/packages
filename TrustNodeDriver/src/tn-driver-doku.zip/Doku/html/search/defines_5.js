var searchData=
[
  ['perm',['PERM',['../d4/dc4/sh__mem_8h.html#ac807e65b8c2cf0d924823993c5d3e99d',1,'sh_mem.h']]],
  ['procfs_5fmax_5fsize',['PROCFS_MAX_SIZE',['../d2/d08/_i_n_r-ctl_8c.html#acb57117519ba69a9fa2bc2ea4661ccaf',1,'INR-ctl.c']]]
];
