var searchData=
[
  ['cpfromshmem',['cpfromshmem',['../d4/dc8/sh__mem_8c.html#a8b85fa444a0a8b6084ed4b4374f1c49f',1,'cpfromshmem(uint16_t *buf, int shID, int semid):&#160;sh_mem.c'],['../d4/dc4/sh__mem_8h.html#a8b85fa444a0a8b6084ed4b4374f1c49f',1,'cpfromshmem(uint16_t *buf, int shID, int semid):&#160;sh_mem.c']]],
  ['cptoshmem',['cptoshmem',['../d4/dc8/sh__mem_8c.html#a390bcefab6c30e196c2d8cd3cd76e323',1,'cptoshmem(uint16_t *buf, int shID, int semid, uint8_t wait, uint8_t flag):&#160;sh_mem.c'],['../d4/dc4/sh__mem_8h.html#a390bcefab6c30e196c2d8cd3cd76e323',1,'cptoshmem(uint16_t *buf, int shID, int semid, uint8_t wait, uint8_t flag):&#160;sh_mem.c']]]
];
