var searchData=
[
  ['get_5fnwdev',['get_nwdev',['../de/dc6/_i_n_r-_n_w_8c.html#a3be8a2ad7ead39dfd6b239b890dc1146',1,'get_nwdev(uint8_t index):&#160;INR-NW.c'],['../dd/de5/_i_n_r-_n_w_8h.html#a3be8a2ad7ead39dfd6b239b890dc1146',1,'get_nwdev(uint8_t index):&#160;INR-NW.c']]],
  ['get_5fpci_5fversion',['get_pci_version',['../dc/dc8/_i_n_r-_p_c_i_8c.html#a3b3eda31e0a953bf76ce7a7239185a6a',1,'INR-PCI.c']]]
];
