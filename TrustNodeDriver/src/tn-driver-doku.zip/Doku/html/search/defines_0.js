var searchData=
[
  ['data_5fsize_5frx',['data_size_rx',['../df/df2/_i_n_r-_p_c_i_8h.html#a72fdcaf31e47536b4b9f088147a7d019',1,'INR-PCI.h']]],
  ['data_5fsize_5ftx',['data_size_tx',['../df/df2/_i_n_r-_p_c_i_8h.html#ab8798c3c5502a8cbe4bfb9c1aaa05ab5',1,'INR-PCI.h']]]
];
