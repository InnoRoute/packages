var searchData=
[
  ['register_5fsize',['REGISTER_SIZE',['../db/d87/_i_n_r_8h.html#abe2f7b6344bb4d51dfea9c9f58609427',1,'INR.h']]]
];
