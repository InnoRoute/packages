var searchData=
[
  ['declare_5fwait_5fqueue_5fhead',['DECLARE_WAIT_QUEUE_HEAD',['../dc/dc8/_i_n_r-_p_c_i_8c.html#a687d7891146109c374c36ee1022065c1',1,'DECLARE_WAIT_QUEUE_HEAD(INR_PCI_TX_unmapd_waittingqueu):&#160;INR-PCI.c'],['../dc/dc8/_i_n_r-_p_c_i_8c.html#a84cc870f5aec647f172a99df0bc416d5',1,'DECLARE_WAIT_QUEUE_HEAD(INR_PCI_rx_pageallocator_waittingqueu):&#160;INR-PCI.c'],['../dc/dc8/_i_n_r-_p_c_i_8c.html#aa786542e09e7b3d8cc17d59196940950',1,'DECLARE_WAIT_QUEUE_HEAD(INR_tailtest):&#160;INR-PCI.c']]],
  ['destroy_5fshmem',['destroy_shmem',['../d4/dc8/sh__mem_8c.html#a3446c06a1bd60dce5a5b8b5a81456c0e',1,'destroy_shmem(int shid, int Semid):&#160;sh_mem.c'],['../d4/dc4/sh__mem_8h.html#a4827e8532f03a58a6197561006121d49',1,'destroy_shmem(int shID, int semid):&#160;sh_mem.c']]]
];
