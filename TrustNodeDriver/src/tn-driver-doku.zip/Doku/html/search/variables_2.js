var searchData=
[
  ['data',['data',['../d4/dad/struct_i_n_r___p_c_i__tx__descriptor__ring__entry.html#a7cfb89a9be0fa0a77d08b69fb6082406',1,'INR_PCI_tx_descriptor_ring_entry::data()'],['../d2/db6/struct_i_n_r___p_c_i__rx__descriptor__ring__entry.html#a5a4900944db9a05ed3e39d63826122cf',1,'INR_PCI_rx_descriptor_ring_entry::data()']]],
  ['data_5frx',['data_rx',['../dc/dc8/_i_n_r-_p_c_i_8c.html#ae3312e6b204907d5268283b31718b397',1,'INR-PCI.c']]],
  ['data_5ftx',['data_tx',['../dc/dc8/_i_n_r-_p_c_i_8c.html#a0e35055fa1b2685390fcb10c138ff0cd',1,'INR-PCI.c']]],
  ['descriptor_5fcurrent_5flastwritten',['descriptor_current_lastwritten',['../dc/dc8/_i_n_r-_p_c_i_8c.html#a504811e8d2faadc833e9b2aa96970b31',1,'INR-PCI.c']]],
  ['dma',['dma',['../d4/dad/struct_i_n_r___p_c_i__tx__descriptor__ring__entry.html#a63ca56f2fcd6fc087457e67d7ce94b6a',1,'INR_PCI_tx_descriptor_ring_entry::dma()'],['../d2/db6/struct_i_n_r___p_c_i__rx__descriptor__ring__entry.html#a7e84e84192330fbce965c89164e9c514',1,'INR_PCI_rx_descriptor_ring_entry::dma()']]],
  ['dma_5frx',['dma_rx',['../dc/dc8/_i_n_r-_p_c_i_8c.html#a5d601ae766f3a0bad64ea0c501661888',1,'INR-PCI.c']]],
  ['dropmode',['dropmode',['../dc/dc8/_i_n_r-_p_c_i_8c.html#a97a71c99d8b265e94eeb2506e4818ff9',1,'INR-PCI.c']]]
];
