var searchData=
[
  ['eop',['eop',['../d4/dad/struct_i_n_r___p_c_i__tx__descriptor__ring__entry.html#ae99fc25b384f15ff80e5a4f80708e333',1,'INR_PCI_tx_descriptor_ring_entry']]],
  ['errors',['Errors',['../d5/d3e/struct_i_n_r___p_c_i__rx__descriptor.html#aeb450fd4afcdc641ba00641bd95f7bee',1,'INR_PCI_rx_descriptor']]]
];
