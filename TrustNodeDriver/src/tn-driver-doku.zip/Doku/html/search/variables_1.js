var searchData=
[
  ['cmd',['CMD',['../dc/d3a/struct_i_n_r___p_c_i__tx__descriptor.html#a7b616ba3405a98b197454798d84ae498',1,'INR_PCI_tx_descriptor']]]
];
