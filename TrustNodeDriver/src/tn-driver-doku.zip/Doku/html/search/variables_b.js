var searchData=
[
  ['skb',['skb',['../d4/dad/struct_i_n_r___p_c_i__tx__descriptor__ring__entry.html#a37ac832d7da4d88e7d326230f1fd1d92',1,'INR_PCI_tx_descriptor_ring_entry']]],
  ['sta',['STA',['../dc/d3a/struct_i_n_r___p_c_i__tx__descriptor.html#a7d2603e2ff99eb600dfed7a11f4249e3',1,'INR_PCI_tx_descriptor']]],
  ['status',['Status',['../d5/d3e/struct_i_n_r___p_c_i__rx__descriptor.html#a46a825059890be604a5be0045cab50ba',1,'INR_PCI_rx_descriptor']]]
];
