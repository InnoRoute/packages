var searchData=
[
  ['gbasehdwr',['gBaseHdwr',['../dc/dc8/_i_n_r-_p_c_i_8c.html#aaa147d86b85150b89188793945c0aec9',1,'INR-PCI.c']]],
  ['gbasehdwr1',['gBaseHdwr1',['../d2/d08/_i_n_r-ctl_8c.html#a1f56f16fd4840e705da69a11a6b6b0a1',1,'INR-ctl.c']]],
  ['gbaselen',['gBaseLen',['../dc/dc8/_i_n_r-_p_c_i_8c.html#a32741943640d9e43a7da378040e0211e',1,'INR-PCI.c']]],
  ['gbaselen1',['gBaseLen1',['../d2/d08/_i_n_r-ctl_8c.html#a57d82805161e905154b75d03a94934d6',1,'INR-ctl.c']]],
  ['gbasevirt',['gBaseVirt',['../dc/dc8/_i_n_r-_p_c_i_8c.html#a08ef92d4c453e0f07295327ae53e80e6',1,'INR-PCI.c']]],
  ['gbasevirt1',['gBaseVirt1',['../d2/d08/_i_n_r-ctl_8c.html#ae56ded3fa2e80123edc6a31dbd0170b1',1,'INR-ctl.c']]],
  ['get_5fnwdev',['get_nwdev',['../de/dc6/_i_n_r-_n_w_8c.html#a3be8a2ad7ead39dfd6b239b890dc1146',1,'get_nwdev(uint8_t index):&#160;INR-NW.c'],['../dd/de5/_i_n_r-_n_w_8h.html#a3be8a2ad7ead39dfd6b239b890dc1146',1,'get_nwdev(uint8_t index):&#160;INR-NW.c']]],
  ['get_5fpci_5fversion',['get_pci_version',['../dc/dc8/_i_n_r-_p_c_i_8c.html#a3b3eda31e0a953bf76ce7a7239185a6a',1,'INR-PCI.c']]],
  ['girq',['gIrq',['../dc/dc8/_i_n_r-_p_c_i_8c.html#adeca6a7cfd438ef4b69255d9052a26d1',1,'INR-PCI.c']]],
  ['globalvar',['globalvar',['../d2/d08/_i_n_r-ctl_8c.html#ad9d1332d79e8693f3080ae2954988294',1,'INR-ctl.c']]]
];
