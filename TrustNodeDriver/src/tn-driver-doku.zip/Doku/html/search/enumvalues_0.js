var searchData=
[
  ['inr_5ftn_5fovsctl_5fcmd_5fadd',['INR_TN_ovsctl_cmd_ADD',['../dc/d62/_i_n_r-ctl_8h.html#ac05c44c7c865ae369322d0ff95776878a62e2183d4b7ef403c7e88957489badb7',1,'INR-ctl.h']]],
  ['inr_5ftn_5fovsctl_5fcmd_5fflush',['INR_TN_ovsctl_cmd_FLUSH',['../dc/d62/_i_n_r-ctl_8h.html#ac05c44c7c865ae369322d0ff95776878a6e908d8cae21dccc6d9b72873de1bcca',1,'INR-ctl.h']]],
  ['inr_5ftn_5fovsctl_5fcmd_5frm',['INR_TN_ovsctl_cmd_RM',['../dc/d62/_i_n_r-ctl_8h.html#ac05c44c7c865ae369322d0ff95776878ab18eac3c5212414571337077928acefd',1,'INR-ctl.h']]]
];
