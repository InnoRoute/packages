var searchData=
[
  ['set_5fnwdev',['set_nwdev',['../de/dc6/_i_n_r-_n_w_8c.html#ae2ed490a9f239ce54dfb26ce4a8e293a',1,'set_nwdev(uint8_t index, struct net_device *dev):&#160;INR-NW.c'],['../dd/de5/_i_n_r-_n_w_8h.html#ae2ed490a9f239ce54dfb26ce4a8e293a',1,'set_nwdev(uint8_t index, struct net_device *dev):&#160;INR-NW.c']]]
];
