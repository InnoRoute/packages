var _i_n_r_8h =
[
    [ "INR_STATUS_BAR0", "db/d87/_i_n_r_8h.html#afa7d0134fc6d33b9756abd6248ea2ffc", null ],
    [ "INR_STATUS_BUSMASTER", "db/d87/_i_n_r_8h.html#a249310d624cece4d9257f6c5b04c7a79", null ],
    [ "INR_STATUS_DEVICE", "db/d87/_i_n_r_8h.html#a832149d7ecd47a44577c669e068d54fc", null ],
    [ "INR_STATUS_DRV_INIT_done", "db/d87/_i_n_r_8h.html#ab2f0f7d94351789b853ca48953864ae8", null ],
    [ "INR_STATUS_HW_RUNNING", "db/d87/_i_n_r_8h.html#a8e6e6632451e62d374dc58249051fc6d", null ],
    [ "INR_STATUS_INT1", "db/d87/_i_n_r_8h.html#a49b7066eadab35c50acda60cab1969d0", null ],
    [ "INR_STATUS_MSI", "db/d87/_i_n_r_8h.html#ae855e911a7a545dac12dade6f1bde2da", null ],
    [ "INR_STATUS_NW_enabled", "db/d87/_i_n_r_8h.html#ae45e5c400209e811da22d9ed89bf0d55", null ],
    [ "INR_STATUS_RX_RING", "db/d87/_i_n_r_8h.html#a1984ae6d17642f72fc74a7f2721c608f", null ],
    [ "INR_STATUS_TX_RING", "db/d87/_i_n_r_8h.html#ae6ae48abb8cc4388447e38765de0edee", null ],
    [ "IRQ_EOI", "db/d87/_i_n_r_8h.html#a830b3aa98adb318f1665f8032554c47c", null ],
    [ "MSI0_IRQ_STATUS", "db/d87/_i_n_r_8h.html#aa664f75b8d67339ff86e7b4ca0311412", null ],
    [ "REGISTER_SIZE", "db/d87/_i_n_r_8h.html#abe2f7b6344bb4d51dfea9c9f58609427", null ],
    [ "INR_CHECK_fpga_read_val", "db/d87/_i_n_r_8h.html#a055451b31abceb46e8c92789d0523980", null ],
    [ "INR_LOG_debug", "db/d87/_i_n_r_8h.html#a549bff83219b80ccf76c695682e37707", null ],
    [ "INR_LOG_timelog", "db/d87/_i_n_r_8h.html#a735c820dfdd991ddd1aa4f802331de2c", null ],
    [ "INR_LOG_timelog_init", "db/d87/_i_n_r_8h.html#a76c866c58615b12b0c38dad30762bfe3", null ],
    [ "INR_NW_STATUS_get", "db/d87/_i_n_r_8h.html#a536dd711b9b013038f5b8d84c88bb6ae", null ],
    [ "INR_NW_STATUS_set", "db/d87/_i_n_r_8h.html#a5c1186ec83dcc67cf53b8cc049118fad", null ],
    [ "INR_STATUS_get", "db/d87/_i_n_r_8h.html#ac9fa7fdfdb1d1521d13b233e604123df", null ],
    [ "INR_STATUS_set", "db/d87/_i_n_r_8h.html#af47261efd77bbc66a759860ab782f170", null ]
];