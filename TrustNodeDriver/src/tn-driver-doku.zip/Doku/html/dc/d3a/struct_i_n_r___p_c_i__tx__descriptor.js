var struct_i_n_r___p_c_i__tx__descriptor =
[
    [ "buffer", "dc/d3a/struct_i_n_r___p_c_i__tx__descriptor.html#a6f3315499b06e8559a4c064ee7d2a57b", null ],
    [ "CMD", "dc/d3a/struct_i_n_r___p_c_i__tx__descriptor.html#a7b616ba3405a98b197454798d84ae498", null ],
    [ "CSO", "dc/d3a/struct_i_n_r___p_c_i__tx__descriptor.html#aa0d64c88781284eb3ec1e19586adff28", null ],
    [ "CSS", "dc/d3a/struct_i_n_r___p_c_i__tx__descriptor.html#a8d4a22dab26a68b75502991fa09b6f45", null ],
    [ "length", "dc/d3a/struct_i_n_r___p_c_i__tx__descriptor.html#a9add5d4d9f47b587d3437b8307f87096", null ],
    [ "Rsvd", "dc/d3a/struct_i_n_r___p_c_i__tx__descriptor.html#af988f4f5defaee4b4bd776568b07e622", null ],
    [ "STA", "dc/d3a/struct_i_n_r___p_c_i__tx__descriptor.html#a7d2603e2ff99eb600dfed7a11f4249e3", null ],
    [ "VLAN", "dc/d3a/struct_i_n_r___p_c_i__tx__descriptor.html#a74593a0d786bfb6992a46d634a37d731", null ]
];