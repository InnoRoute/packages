var _i_n_r_ctl_8h =
[
    [ "INR_PCI_BAR1_read", "dc/d62/_i_n_r-ctl_8h.html#af95c6711b855f4cad5d0ad91b2ef2693", null ],
    [ "INR_PCI_BAR1_write", "dc/d62/_i_n_r-ctl_8h.html#a33596740556b718c5de1a9b7ed521aed", null ],
    [ "INR_TN_ovsctl_cmd_type", "dc/d62/_i_n_r-ctl_8h.html#ac05c44c7c865ae369322d0ff95776878", [
      [ "INR_TN_ovsctl_cmd_ADD", "dc/d62/_i_n_r-ctl_8h.html#ac05c44c7c865ae369322d0ff95776878a62e2183d4b7ef403c7e88957489badb7", null ],
      [ "INR_TN_ovsctl_cmd_RM", "dc/d62/_i_n_r-ctl_8h.html#ac05c44c7c865ae369322d0ff95776878ab18eac3c5212414571337077928acefd", null ],
      [ "INR_TN_ovsctl_cmd_FLUSH", "dc/d62/_i_n_r-ctl_8h.html#ac05c44c7c865ae369322d0ff95776878a6e908d8cae21dccc6d9b72873de1bcca", null ]
    ] ],
    [ "INR_CTL_init_ovs", "dc/d62/_i_n_r-ctl_8h.html#a476d839aa251268ad30ad266f9f35a11", null ],
    [ "INR_CTL_init_proc", "dc/d62/_i_n_r-ctl_8h.html#a53b5a28c7c3b608c419eb5f9da6f197b", null ],
    [ "INR_CTL_ovs_d", "dc/d62/_i_n_r-ctl_8h.html#a9c189ca74efb7ebe5f93ab70e6bed1bf", null ],
    [ "INR_CTL_ovs_flow_add", "dc/d62/_i_n_r-ctl_8h.html#a258461947d6d8a65133a37dfb1059f03", null ],
    [ "INR_CTL_ovs_flow_flush", "dc/d62/_i_n_r-ctl_8h.html#a1953b2b2931dc44bd148b24ffa5df7c5", null ],
    [ "INR_CTL_ovs_flow_rm", "dc/d62/_i_n_r-ctl_8h.html#ad50ecd41f0181d2f49596aaa2306313f", null ],
    [ "INR_CTL_remove_proc", "dc/d62/_i_n_r-ctl_8h.html#aba50eabbac94466b4c31d4fb64824e55", null ]
];