var struct_i_n_r___p_c_i__rx__descriptor =
[
    [ "buffer", "d5/d3e/struct_i_n_r___p_c_i__rx__descriptor.html#a55af0fc445cc9d4e3896436ef8abe075", null ],
    [ "Errors", "d5/d3e/struct_i_n_r___p_c_i__rx__descriptor.html#aeb450fd4afcdc641ba00641bd95f7bee", null ],
    [ "FragmentCS", "d5/d3e/struct_i_n_r___p_c_i__rx__descriptor.html#aa4476eefc04a080712afc3395619e20e", null ],
    [ "length", "d5/d3e/struct_i_n_r___p_c_i__rx__descriptor.html#ad2300af5cd28909a5e130d4c1ef06355", null ],
    [ "Status", "d5/d3e/struct_i_n_r___p_c_i__rx__descriptor.html#a46a825059890be604a5be0045cab50ba", null ],
    [ "VLAN", "d5/d3e/struct_i_n_r___p_c_i__rx__descriptor.html#a650a33d7ca3ff807ecb9deda48c42807", null ]
];