var struct_i_n_r___p_c_i__tx__descriptor__ring__entry =
[
    [ "data", "d4/dad/struct_i_n_r___p_c_i__tx__descriptor__ring__entry.html#a7cfb89a9be0fa0a77d08b69fb6082406", null ],
    [ "dma", "d4/dad/struct_i_n_r___p_c_i__tx__descriptor__ring__entry.html#a63ca56f2fcd6fc087457e67d7ce94b6a", null ],
    [ "eop", "d4/dad/struct_i_n_r___p_c_i__tx__descriptor__ring__entry.html#ae99fc25b384f15ff80e5a4f80708e333", null ],
    [ "length", "d4/dad/struct_i_n_r___p_c_i__tx__descriptor__ring__entry.html#ab65e7ed9211023c2417766acdbfc9b0f", null ],
    [ "paged", "d4/dad/struct_i_n_r___p_c_i__tx__descriptor__ring__entry.html#acf71b2952a6fb4054bd869b56ccf3248", null ],
    [ "skb", "d4/dad/struct_i_n_r___p_c_i__tx__descriptor__ring__entry.html#a37ac832d7da4d88e7d326230f1fd1d92", null ]
];