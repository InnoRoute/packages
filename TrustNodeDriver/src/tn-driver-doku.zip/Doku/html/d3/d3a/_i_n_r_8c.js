var _i_n_r_8c =
[
    [ "INR_CHECK_fpga_read_val", "d3/d3a/_i_n_r_8c.html#a055451b31abceb46e8c92789d0523980", null ],
    [ "INR_LOG_debug", "d3/d3a/_i_n_r_8c.html#a549bff83219b80ccf76c695682e37707", null ],
    [ "INR_LOG_timelog", "d3/d3a/_i_n_r_8c.html#a735c820dfdd991ddd1aa4f802331de2c", null ],
    [ "INR_LOG_timelog_init", "d3/d3a/_i_n_r_8c.html#a6bd334356f0c45c0414024cabe5f2315", null ],
    [ "INR_NW_STATUS_get", "d3/d3a/_i_n_r_8c.html#a536dd711b9b013038f5b8d84c88bb6ae", null ],
    [ "INR_NW_STATUS_set", "d3/d3a/_i_n_r_8c.html#a5c1186ec83dcc67cf53b8cc049118fad", null ],
    [ "INR_STATUS_get", "d3/d3a/_i_n_r_8c.html#ac9fa7fdfdb1d1521d13b233e604123df", null ],
    [ "INR_STATUS_set", "d3/d3a/_i_n_r_8c.html#af47261efd77bbc66a759860ab782f170", null ],
    [ "debug_enable", "d3/d3a/_i_n_r_8c.html#a69d401de09f6d6763364549ef690d01b", null ],
    [ "fpga_read_check", "d3/d3a/_i_n_r_8c.html#a428fa7ce41b6cf772d8c608298ee8d40", null ],
    [ "INR_LOG_lasttime", "d3/d3a/_i_n_r_8c.html#a85498b613462ef50f80c631e36f1033e", null ],
    [ "INR_NW_status", "d3/d3a/_i_n_r_8c.html#a8567ff109cfaa47f88d5401f94717cd0", null ],
    [ "INR_status", "d3/d3a/_i_n_r_8c.html#a5b8661948451ce36eb92e997a1c75c7d", null ],
    [ "timelog_enable", "d3/d3a/_i_n_r_8c.html#a7b1238a2c6f19ad94c0788093d9d28ec", null ]
];