var struct_i_n_r___n_w__packet =
[
    [ "data", "d3/d1d/struct_i_n_r___n_w__packet.html#a9cf03949dbb04cd1da9009a8e6a79b4f", null ],
    [ "datalen", "d3/d1d/struct_i_n_r___n_w__packet.html#a3c1ce8207da3b6f04986dd1d08e856eb", null ],
    [ "dev", "d3/d1d/struct_i_n_r___n_w__packet.html#a7ecb2831f6bd10023ae39a21a14dd2ad", null ],
    [ "next", "d3/d1d/struct_i_n_r___n_w__packet.html#a7950ed673e0bc6d4bf59b363337b863b", null ]
];