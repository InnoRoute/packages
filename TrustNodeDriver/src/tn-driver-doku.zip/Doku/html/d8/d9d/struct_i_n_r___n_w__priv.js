var struct_i_n_r___n_w__priv =
[
    [ "dev", "d8/d9d/struct_i_n_r___n_w__priv.html#a8ca61a800d5a99b33c865e1b741b3213", null ],
    [ "lock", "d8/d9d/struct_i_n_r___n_w__priv.html#a09ad9837ecaa9173104b708d567fddda", null ],
    [ "napi", "d8/d9d/struct_i_n_r___n_w__priv.html#a16f03862701c1ea24fc726b6315ee074", null ],
    [ "port", "d8/d9d/struct_i_n_r___n_w__priv.html#a13acc455305a73517b58f83330834583", null ],
    [ "ppool", "d8/d9d/struct_i_n_r___n_w__priv.html#a8343b67b079918225f8682aa01571dba", null ],
    [ "rx_int_enabled", "d8/d9d/struct_i_n_r___n_w__priv.html#aca46e208e97d1f618bb5eaeff326eb90", null ],
    [ "rx_queue", "d8/d9d/struct_i_n_r___n_w__priv.html#aed02e67f3912a83a33795063013aeed0", null ],
    [ "skb", "d8/d9d/struct_i_n_r___n_w__priv.html#a48991c4c0750b975ddbfaba5002b8b5a", null ],
    [ "stats", "d8/d9d/struct_i_n_r___n_w__priv.html#aa52999d759e7dfa99f42d5835b74a1cb", null ],
    [ "status", "d8/d9d/struct_i_n_r___n_w__priv.html#a958c716b3e6d545a5430d21122f20bf9", null ],
    [ "tx_packetdata", "d8/d9d/struct_i_n_r___n_w__priv.html#a6325072eb0045df4926b9d3b1dcd851c", null ],
    [ "tx_packetlen", "d8/d9d/struct_i_n_r___n_w__priv.html#a0cf6f324186fff691897330db1b279c1", null ]
];