var struct_i_n_r___p_c_i__rx__descriptor__ring__entry =
[
    [ "data", "d2/db6/struct_i_n_r___p_c_i__rx__descriptor__ring__entry.html#a5a4900944db9a05ed3e39d63826122cf", null ],
    [ "dma", "d2/db6/struct_i_n_r___p_c_i__rx__descriptor__ring__entry.html#a7e84e84192330fbce965c89164e9c514", null ],
    [ "dma_root", "d2/db6/struct_i_n_r___p_c_i__rx__descriptor__ring__entry.html#ad6ab8a05d59ebc41c002ca63e574c3ab", null ],
    [ "fragmentindex", "d2/db6/struct_i_n_r___p_c_i__rx__descriptor__ring__entry.html#a4c3bf358a50ff972165433f7d60da3d5", null ],
    [ "offset", "d2/db6/struct_i_n_r___p_c_i__rx__descriptor__ring__entry.html#ad3b84006086822db04cbf62757be7ffa", null ],
    [ "page", "d2/db6/struct_i_n_r___p_c_i__rx__descriptor__ring__entry.html#ab17d4a4ae6f92408110b4800ffabe555", null ]
];