var _i_n_r__n_a_p_i_8c =
[
    [ "INR_NAPI_complete", "d1/d67/_i_n_r-_n_a_p_i_8c.html#a517ed25d9d1f3ee1c648633b74f4469b", null ],
    [ "INR_NAPI_init", "d1/d67/_i_n_r-_n_a_p_i_8c.html#a4d6b9bd7496ab1a6ae8d17e5889d6adb", null ],
    [ "INR_NAPI_poll_0", "d1/d67/_i_n_r-_n_a_p_i_8c.html#a87ec5cd355cffe8b96296dbb83278bfe", null ],
    [ "INR_NAPI_poll_1", "d1/d67/_i_n_r-_n_a_p_i_8c.html#a938e6a3d06b11a5dc3da541a5d05c0b2", null ],
    [ "INR_NAPI_poll_10", "d1/d67/_i_n_r-_n_a_p_i_8c.html#a69ec3410fe5dc7da35e2f6a8d72acdb4", null ],
    [ "INR_NAPI_poll_11", "d1/d67/_i_n_r-_n_a_p_i_8c.html#a7b9c6dd796e70895de209d2803e13ccc", null ],
    [ "INR_NAPI_poll_12", "d1/d67/_i_n_r-_n_a_p_i_8c.html#a3a1602b0c3f015b8aabd0b978d704493", null ],
    [ "INR_NAPI_poll_13", "d1/d67/_i_n_r-_n_a_p_i_8c.html#a2ee390e1624519f6a631b3046c2fbd3f", null ],
    [ "INR_NAPI_poll_14", "d1/d67/_i_n_r-_n_a_p_i_8c.html#a2cbf12b9e0e03b3b3862a98784ecc52b", null ],
    [ "INR_NAPI_poll_15", "d1/d67/_i_n_r-_n_a_p_i_8c.html#a91f701f31afe930ece5c8bf5fb1a7ed6", null ],
    [ "INR_NAPI_poll_2", "d1/d67/_i_n_r-_n_a_p_i_8c.html#ae6bc59b863b3928700468d13efd23e27", null ],
    [ "INR_NAPI_poll_3", "d1/d67/_i_n_r-_n_a_p_i_8c.html#a7888221fd9575d7e7aae78ed125d8646", null ],
    [ "INR_NAPI_poll_4", "d1/d67/_i_n_r-_n_a_p_i_8c.html#a5e711c1ae61572a4bab9ffefc34d0f34", null ],
    [ "INR_NAPI_poll_5", "d1/d67/_i_n_r-_n_a_p_i_8c.html#a4c7935fe4ef401ccd186e05e1047748c", null ],
    [ "INR_NAPI_poll_6", "d1/d67/_i_n_r-_n_a_p_i_8c.html#a2a63c16bad3fb8de0dacd9bb0b02a40f", null ],
    [ "INR_NAPI_poll_7", "d1/d67/_i_n_r-_n_a_p_i_8c.html#a05cb8dc7168c07cf8755dc8e4075caba", null ],
    [ "INR_NAPI_poll_8", "d1/d67/_i_n_r-_n_a_p_i_8c.html#a56cfbbdff0a9b3fba466a06079b21ed8", null ],
    [ "INR_NAPI_poll_9", "d1/d67/_i_n_r-_n_a_p_i_8c.html#a7411c18801eb32e892612975b01d604e", null ],
    [ "INR_NAPI_remove", "d1/d67/_i_n_r-_n_a_p_i_8c.html#a1820e5e0fd46d9e11c8c5d0003a12d2d", null ],
    [ "INR_NAPI_schedule", "d1/d67/_i_n_r-_n_a_p_i_8c.html#ab0128b9e2aa3db2fe73ce3475130d2d2", null ],
    [ "INR_NAPI_rx", "d1/d67/_i_n_r-_n_a_p_i_8c.html#a9e76c9c65425d05e8e833502a24efcc7", null ]
];