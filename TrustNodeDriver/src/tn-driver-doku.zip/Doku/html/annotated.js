var annotated =
[
    [ "INR_NW_packet", "d3/d1d/struct_i_n_r___n_w__packet.html", "d3/d1d/struct_i_n_r___n_w__packet" ],
    [ "INR_NW_priv", "d8/d9d/struct_i_n_r___n_w__priv.html", "d8/d9d/struct_i_n_r___n_w__priv" ],
    [ "INR_PCI_rx_descriptor", "d5/d3e/struct_i_n_r___p_c_i__rx__descriptor.html", "d5/d3e/struct_i_n_r___p_c_i__rx__descriptor" ],
    [ "INR_PCI_rx_descriptor_ring_entry", "d2/db6/struct_i_n_r___p_c_i__rx__descriptor__ring__entry.html", "d2/db6/struct_i_n_r___p_c_i__rx__descriptor__ring__entry" ],
    [ "INR_PCI_tx_descriptor", "dc/d3a/struct_i_n_r___p_c_i__tx__descriptor.html", "dc/d3a/struct_i_n_r___p_c_i__tx__descriptor" ],
    [ "INR_PCI_tx_descriptor_ring_entry", "d4/dad/struct_i_n_r___p_c_i__tx__descriptor__ring__entry.html", "d4/dad/struct_i_n_r___p_c_i__tx__descriptor__ring__entry" ]
];