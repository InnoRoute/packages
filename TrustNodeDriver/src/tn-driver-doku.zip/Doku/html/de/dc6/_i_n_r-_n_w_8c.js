var _i_n_r__n_w_8c =
[
    [ "get_nwdev", "de/dc6/_i_n_r-_n_w_8c.html#a3be8a2ad7ead39dfd6b239b890dc1146", null ],
    [ "INR_NW_change_mtu", "de/dc6/_i_n_r-_n_w_8c.html#a50081b211a56adba3d006e0d1217b1e4", null ],
    [ "INR_NW_config", "de/dc6/_i_n_r-_n_w_8c.html#a20dce5ca3a09dd03f5749dd65ce537a9", null ],
    [ "INR_NW_init", "de/dc6/_i_n_r-_n_w_8c.html#a7b526b67a1a857f6ccc0c846151d732f", null ],
    [ "INR_NW_ioctl", "de/dc6/_i_n_r-_n_w_8c.html#a5b4be059f962691ee3a2ea1916581a8f", null ],
    [ "INR_NW_open", "de/dc6/_i_n_r-_n_w_8c.html#a3c5997cfd98ac8aa47a8b72bd7679866", null ],
    [ "INR_NW_rx", "de/dc6/_i_n_r-_n_w_8c.html#aaba3f0bc97075473952ec438fe917f05", null ],
    [ "INR_NW_set_features", "de/dc6/_i_n_r-_n_w_8c.html#ac8b9ee10763c33262bc89ea095e22682", null ],
    [ "INR_NW_stats", "de/dc6/_i_n_r-_n_w_8c.html#abb319f65421dabda9340aaf552ea54ba", null ],
    [ "INR_NW_stop", "de/dc6/_i_n_r-_n_w_8c.html#a4fe1414ed84f58a4448cd07ba24d7317", null ],
    [ "INR_NW_tx", "de/dc6/_i_n_r-_n_w_8c.html#adca6307173d3752d1f3bc9285b0cb25c", null ],
    [ "INR_NW_tx_timeout", "de/dc6/_i_n_r-_n_w_8c.html#a873b31f10f306248e842e2998edd25ac", null ],
    [ "set_nwdev", "de/dc6/_i_n_r-_n_w_8c.html#ae2ed490a9f239ce54dfb26ce4a8e293a", null ],
    [ "globnwdev", "de/dc6/_i_n_r-_n_w_8c.html#a6dfb9b620f637dfc838a9361f7daba46", null ],
    [ "nwdev_counter", "de/dc6/_i_n_r-_n_w_8c.html#a91e29a1bdce55f81f7ba34d3ef5060b5", null ]
];